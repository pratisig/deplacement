# FlowMap 7.6 - cartes de flux animees dans ArcGIS Pro

Un outil, une table : choisissez la table, les champs dans les menus deroulants,
cliquez sur **Run**. Vous obtenez :

1. **une page HTML autonome** (identique a l'exemple du Yemen : animation, curseur
   de temps, recherche, exports GIF/video/SHP/GeoJSON/CSV) ;
2. **les limites administratives** (regions ADM1 + districts ADM2) des pays ou se
   trouvent les donnees, telechargees automatiquement (geoBoundaries), dessinees
   sur la page ET ajoutees a la carte ;
3. **dans ArcGIS Pro** : couches *Regions*, *Districts*, *Flows* (activee dans le
   temps : ouvrez le **Time Slider** et appuyez sur Play) et *Places* (points
   dimensionnes par volume). Tout est dans `FlowMap.gdb` du dossier de sortie.

## Installation

1. Copiez tout le dossier (il faut `FlowMap.pyt`, `flowmap_core.py`, `index.html`
   et les `.xml`) dans un dossier permanent.
2. Pro : **Insert > Toolbox > Add Toolbox...** puis `FlowMap.pyt`
   (retirez d'abord toute ancienne version de la toolbox : clic droit > Remove).
3. Ouvrez **Flow map > Build a flow map page (7.6)**.

## Utilisation

- **Flow table or layer** : une couche de la carte, ou *Parcourir* vers un CSV,
  une feuille Excel, une table, une classe d'entites.
- Les menus **Place name / Value / Date / Longitude / Latitude** proposent les
  colonnes de cette table (champs natifs de Pro, relies a la table : ils se
  remplissent des que la table est choisie). Aucun champ n'est pre-rempli.
- Il faut au minimum les **noms de lieux** ou les **longitude/latitude** (une
  couche de points n'a besoin d'aucun champ : sa geometrie sert de position).
- **Load the administrative boundaries** (coche par defaut) : les pays sont
  detectes a partir des coordonnees ; si la table n'a que des noms de lieux,
  saisissez les codes pays (ex. `YEM, MLI`) dans *Countries*.
  Premiere execution : internet requis ; ensuite tout est garde dans
  `admin_cache/` du dossier de sortie. Sans internet, la page est quand meme creee.
- Vos propres limites (*Places and outlines*) remplacent celles telechargees.

## Si quelque chose ne marche pas

Executez `python check_install.py` (Python Command Prompt de ArcGIS Pro) :
il verifie les fichiers, la version, les menus de champs et l'acces internet.

## Hors ArcGIS

```
python flowmap_core.py demo --out demo.html
python flowmap_core.py selftest
```

## La carte HTML

- Elle s'ouvre **cadree sur l'etendue reelle des points** (pas sur le pays entier).
- **Zoom** : molette, double-clic, boutons **+ / -** ; **deplacer** : glisser a la souris ;
  **Fit data** : revient au cadrage des donnees.
- Fond de carte (Dark / Light / Terrain / Satellite) : tuiles en ligne, internet requis
  pour le fond ; sans internet, points, flux et limites s'affichent quand meme.

## Exports de la page

**Export > Map (PDF, A4)** : carte imprimable avec titre, periode, fleche nord, echelle,
legende et source ; orientation **portrait ou paysage choisie automatiquement** selon la
forme de l'etendue (ou de la vue zoomee). L'echelle n'est pas tracee en mode « Network ».
Les exports GIF et video fonctionnent aussi avec le fond de carte (les tuiles sont lues
avec CORS ; si un serveur le refuse, l'export se fait sans fond de carte et le dit).
La source est le nom de la table chargee (modifiable dans *Source note*).

## Limites administratives : seulement la ou sont les donnees

- Les pays sont detectes point par point ; un pays n'est garde que s'il contient au moins
  15 % des points (quelques villages pres d'une frontiere n'ajoutent pas le pays voisin).
- Seules les regions/districts situes autour des donnees sont gardes, sur la page comme
  dans la carte ArcGIS Pro.

## Mise en page 7.6

La page est organisee comme une application : en-tete (titre, indicateurs, couches, Notes, FR/EN, exports), filtres / periode / nombre de routes / legende a gauche, carte au centre, quatre panneaux a droite (routes, destinations, regions d'arrivee, solde net) et bandeau d'analyse sous la carte. Sur telephone, tout passe en une colonne.

**Important** : `index.html` doit etre celui du meme zip que `FlowMap.pyt`. Si l'ancien modele est utilise, l'outil l'indique en avertissement.

## Integrer dans ArcGIS Experience Builder

Menu **Exporter > Integrer (Experience Builder)...** : la page genere l'adresse et le code `<iframe>`
a coller dans le widget *Embed* (mode URL ou Code), avec des options (panneaux lateraux, barre de titre,
langue, theme). Une page ouverte dans un cadre passe automatiquement en mise en page compacte ;
parametres d'adresse : `embed=1`, `panels=0`, `header=0`, `lang=fr|en`, `mode=dark|light`.
Deux voies : (1) page hebergee en HTTPS (recommande) ; (2) copie du code de la page entiere
(sans hebergement, mais certains Portal retirent les scripts ou limitent la taille). A verifier cote
organisation : HTTPS, serveur autorisant l'affichage en cadre (X-Frame-Options / frame-ancestors),
liste des sites integrables, acces aux serveurs de tuiles. Non teste dans un vrai Experience Builder.

## Nouveautes 7.4 (inspirees de l'application Ituri)

- **Langue de la page** (English / Francais) : boutons, textes et PDF ; un bouton FR/EN reste sur la page.
- **Couche thematique par zone** (section *Values by area*) : une couche de polygones, ou une table
  (nom de zone + valeur) rapprochee des limites chargees, coloree sous les flux (ex. cas par zone de sante).
  Elle est aussi ajoutee a Pro (couche *Area values*, classes graduees).
- **Filtres et tableau de bord** sur la page : province/zone (avec zoom), plage de periode, indicateurs,
  principales routes et destinations, solde net, curseur du nombre de routes, fleches de direction.
- **Notes et sources** : champ *Notes* de l'outil, affiche dans une boite de dialogue avec une phrase
  de synthese automatique.

## Limites connues

- Les limites geoBoundaries sont simplifiees (legeres) ; les noms de districts de votre
  table et ceux de geoBoundaries peuvent differer : les flux utilisent vos coordonnees,
  ou vos propres limites si vous les fournissez.
- L'activation du temps sur la couche *Flows* est tentee automatiquement ; si votre
  version de Pro la refuse, l'outil l'indique : *Layer Properties > Time*, champ `WHEN`.
